# Project Name: ~/Directory

## Overview

~/Directory is a web application that helps users store a comprehensive list of information about contacts to be stored.It's  major  purpose is storage , and filtering stored data to obtain results quickly.

## Features

* Linkage of information with a Database to give quick and easy access of information.
* The ability to edit and delete existing folders.
* Search implemented in a filter format.
* Security implementation , by requiring a master key to access and edit the database
* Prevention of storage of incorrect information , by fields only accepting certain formats.
* Prevention of duplicates and redundancy.

## Architecture

~/Directory is built using the following technologies:

* **Front-end:** JS, HTML, CSS
* **Back-end:** Python, sqlite3,SqlAlchemy.
* **Authentication:** JavaScript

The front end is built utilising HTML,CSS and JS , the Backend is constructed using Python, SQllite3,SQLAlchemy.

## Getting Started

To run ~/Directory, you will need to:

1. Unzip the file
2. Run rhe following commands :
3. * flask shell
   * from app import db,Student,Teacher
   * db.create_all()
4. Start the server using the following commands in the new terminal:
   * export flask_APP=app
   * export flask_ENV=development
   * flask run
5. Open the local host server as displayed in the terminal
6. Going through the website is intuitive

## Contributions

* Kavish Kapoor: Handled Backend And Site Design : Python(FLask),SQLAlchemy,Sqlite, .
* Sairam Narendra Babu : Handled FrontEnd and Site Design: HTML,CSS,JS
* Viswanath Vuppala : Handled FrontEnd and Site Design : HTML,CSS

## Conclusion 
The hackathon gave us insight into webdevelopment projects and how they are handled . The Website is fully functional and its theme is TUI/retroarcade inspired. Its built to be easily usable and understandable. 



